package org.capstore.model;

public class Cap {

}
