package com.capgemini.capstore.service;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.capstore.domain.Address;
import com.capgemini.capstore.domain.Cart;
import com.capgemini.capstore.domain.Category;
import com.capgemini.capstore.domain.Customer;
import com.capgemini.capstore.domain.Image;
import com.capgemini.capstore.domain.Merchant;
import com.capgemini.capstore.domain.Order;
import com.capgemini.capstore.domain.Product;
import com.capgemini.capstore.domain.Review;
import com.capgemini.capstore.domain.WishList;

import antlr.collections.List;

public class ServiceClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Address address=new Address();
		address.setAddressLine("Shree balaji complex");
		
		Image image1=new Image();
		Image image2=new Image();
		ArrayList<Image> imageList=new ArrayList<Image>();
		imageList.add(image1);
		imageList.add(image2);
		
		Product product1=new Product();
		product1.setImage(imageList);
		Product product2=new Product();
		product2.setImage(imageList);
		ArrayList<Product> productList=new ArrayList<Product>();
		productList.add(product1);
		productList.add(product2);
	
		Cart cart=new Cart();
		cart.setProductList(productList);
		
		WishList wishlist=new WishList();
		wishlist.setWishList(productList);
		
		Review review=new Review();
		review.setProduct(product1);
		review.setReview("nice");
		
		Category category=new Category();
		category.setName("home");
		category.setProducts(productList);
		
		
		
		Merchant merchant=new Merchant();
		merchant.setName("tejal");
		
		Customer customer=new Customer();
		customer.setEmail("tejal.tandale@capgemini.com");
		customer.setAddress(address);
		customer.setCart(cart);
		customer.setWishList(wishlist); 
		
		
		Order order=new Order();
		order.setProduct(productList);
		order.setCustomer(customer);
	

		em.persist(merchant);
		em.persist(merchant);
		em.persist(order);
		
		em.getTransaction().commit();
		
		
	
		
		
		em.close();
		emf.close();
		
		
		

	}

}
