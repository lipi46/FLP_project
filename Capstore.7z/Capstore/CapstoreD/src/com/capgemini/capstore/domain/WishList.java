package com.capgemini.capstore.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class WishList {

	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@OneToMany
	private List<Product> wishList;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<Product> getWishList() {
		return wishList;
	}
	public void setWishList(List<Product> wishList) {
		this.wishList = wishList;
	}
	
	public WishList(){}
	@Override
	public String toString() {
		return "WishList [id=" + id + ", wishList=" + wishList + "]";
	}
	
	
}
