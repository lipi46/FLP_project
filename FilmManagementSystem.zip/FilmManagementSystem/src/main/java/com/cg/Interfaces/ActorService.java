package com.cg.Interfaces;





import java.util.Set;

import com.cg.Pojo.Actor;

public interface ActorService {

	String createActor(Actor actor);
	String removeActor(String firstName,String lastName);
	String modifyActor(String firstName,String lastName);
	Actor searchActorByName(String firstName,String lastName);
	Set<com.cg.Pojo.Actor> getAllActors();
}
